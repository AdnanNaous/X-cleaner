'use strict';
importScripts('shared.js');

const { sections } = Cleaner;
const MAX_PASSES = 2;
const STORAGE = 'job';
const MAX_ITEM_ATTEMPTS = 2;
const WATCHDOG = 'cleanup-health';
let queue = Promise.resolve();
let badgeText;

function serial(operation) {
  const response = queue.then(operation);
  queue = response.catch(() => {});
  return response;
}

async function read() {
  return (await chrome.storage.session.get(STORAGE))[STORAGE];
}

async function report(job, includeCheckpoint = false) {
  if (job) return job;
  const saved = await chrome.storage.local.get(['report', 'checkpoint']);
  if (!saved.report) return null;
  return includeCheckpoint ? { ...saved.report, ...saved.checkpoint } : saved.report;
}

function itemKey(item) {
  return item.kind + ':' + item.url.split('/').at(-1);
}

function addEvent(job, text) {
  (job.events ||= []).push({ time: Date.now(), text });
  job.events = job.events.slice(-15);
}

function rememberFailure(job, item) {
  const failed = job.itemFailures ||= {};
  const key = itemKey(item);
  const previous = failed[key];
  const attempts = (typeof previous === 'number' ? previous : previous?.attempts || 0) + 1;
  failed[key] = { attempts, retryAt: Date.now() + Cleaner.itemRetryRest };
  return attempts;
}

async function write(job) {
  job.revision = (job.revision || 0) + 1;
  await chrome.storage.session.set({ [STORAGE]: job });
  const { documentId, pending, itemFailures, confirmed, ...snapshot } = job;
  await chrome.storage.local.set({ report: snapshot, checkpoint: { pending, itemFailures, confirmed } });
  const text = job.alertPending ? '!' : '';
  if (chrome.action && badgeText !== text) {
    try {
      await chrome.action.setBadgeText({ text });
      badgeText = text;
    } catch (error) {
      console.warn('Could not update the X Cleaner badge.', error);
    }
  }
  if (!['running', 'stopping'].includes(job.status)) await releaseTab(job);
}

async function protectTab(job) {
  const tab = await chrome.tabs.get(job.tabId);
  job.originalAutoDiscardable ??= tab.autoDiscardable !== false;
  await chrome.tabs.update(job.tabId, { autoDiscardable: false });
  if (chrome.alarms && !await chrome.alarms.get(WATCHDOG)) {
    await chrome.alarms.create(WATCHDOG, { periodInMinutes: 0.5 });
  }
}

async function releaseTab(job) {
  if (chrome.alarms) await chrome.alarms.clear(WATCHDOG);
  if (job.originalAutoDiscardable === undefined) return;
  try {
    await chrome.tabs.update(job.tabId, { autoDiscardable: job.originalAutoDiscardable });
  } catch {
    // The cleanup tab may have been closed.
  }
}

async function pause(job, reason, kind = 'issue') {
  if (job.pending) {
    const url = job.pending.url;
    recordInterruptedAction(job, 'The last action was interrupted before X confirmed it.');
    reason += ` Check the last attempted item: ${url}`;
  }
  job.status = 'paused';
  job.pauseKind = kind;
  job.alertPending = kind !== 'manual';
  job.pausedAt = Date.now();
  job.ratePaused = kind === 'rate-limit';
  job.waitUntil = job.ratePaused ? job.pausedAt + Cleaner.rateRest : 0;
  job.message = reason;
  addEvent(job, reason);
  job.documentId = null;
  job.pending = null;
  await write(job);
  return job;
}

function atSection(job, url) {
  return Cleaner.atSection(job.section, url, job.handle, job.history, job.replySearch, job.repostProfile);
}

async function navigate(job, { refresh = false } = {}) {
  const target = Cleaner.sectionTarget(job.section, job.handle, job.history, job.replySearch, job.repostProfile);
  job.documentId = null;
  job.lastContact = Date.now();
  try {
    await protectTab(job);
    await write(job);
    const tab = await chrome.tabs.get(job.tabId);
    if (refresh && atSection(job, tab.url) && !tab.pendingUrl) {
      await chrome.tabs.reload(job.tabId, { bypassCache: true });
    } else {
      await chrome.tabs.update(job.tabId, { url: target });
    }
  } catch {
    await pause(job, 'The cleanup tab is unavailable. Continue cleanup to reopen it.');
  }
}

async function checkHealth() {
  const job = await read();
  if (!job || !['running', 'stopping'].includes(job.status)) {
    if (chrome.alarms) await chrome.alarms.clear(WATCHDOG);
    return;
  }
  let tab;
  try {
    tab = await chrome.tabs.get(job.tabId);
  } catch {
    await pause(job, 'The cleanup tab closed. Continue cleanup to reopen it.');
    return;
  }
  if (tab.pendingUrl || tab.status === 'loading') {
    if (Date.now() - job.lastContact < 90000) return;
  } else if (!atSection(job, tab.url)) {
    await recoverRoute(job, tab.url);
    return;
  }
  if (tab.frozen) {
    await chrome.tabs.update(job.tabId, { active: true });
    job.message = 'Chrome suspended the cleanup tab. Reactivating it.';
    addEvent(job, job.message);
    await write(job);
  }
  if (job.status === 'stopping') {
    if (!job.pending || Date.now() - (job.actionStartedAt || job.lastContact) > 60000) {
      await pause(job, 'Stopped. The last unconfirmed action will be checked when you continue.', 'manual');
    }
    return;
  }
  const deadline = Math.max(job.lastContact || 0, job.nextActionAt || 0);
  const stalledLoad = (tab.pendingUrl || tab.status === 'loading') &&
    Date.now() - (job.lastContact || 0) >= 90000;
  if (!tab.discarded && !stalledLoad && Date.now() - deadline < 90000) return;
  if ((job.watchdogRecoveries || 0) >= 2) {
    await unavailableSection(job, 'The cleanup page stopped responding after two reloads.');
    return;
  }
  job.watchdogRecoveries = (job.watchdogRecoveries || 0) + 1;
  recordInterruptedAction(job, 'The page stopped responding before the last action was confirmed.');
  job.message = 'The cleanup page stopped responding. Reloading and resuming this section.';
  addEvent(job, job.message);
  await navigate(job, { refresh: true });
}

async function openSection(job, { repostProfile = false } = {}) {
  const unavailable = job.unavailable?.[job.section];
  if (unavailable) {
    await finishSection(job, { result: 'review', detail: unavailable });
    return;
  }
  job.history = false;
  job.replySearch = false;
  job.repostProfile = repostProfile;
  job.repostIssue = repostProfile ? job.repostIssue : null;
  job.skippedHere = 0;
  job.batchActions = 0;
  job.recoveries = 0;
  job.watchdogRecoveries = 0;
  job.redirects = 0;
  job.refreshPending = false;
  job.waitUntil = 0;
  job.message = `Opening ${sections[job.section].name}…`;
  addEvent(job, `Pass ${job.pass} · ${job.message}`);
  await navigate(job);
}

function recordInterruptedAction(job, text) {
  if (!job.pending) return;
  job.totals.errors++;
  rememberFailure(job, job.pending);
  job.problem = { text, url: job.pending.url };
  job.nextActionAt = Math.max(job.nextActionAt, Date.now() + (job.pace ?? Cleaner.defaultPace));
  job.pending = null;
}

async function openHistory(job) {
  job.history = true;
  job.redirects = 0;
  job.recoveries = 0;
  job.watchdogRecoveries = 0;
  job.message = `Looking for ${sections[job.section].name} in History…`;
  await navigate(job);
}

async function openReplySearch(job) {
  job.replySearch = true;
  job.skippedHere = 0;
  job.redirects = 0;
  job.recoveries = 0;
  job.watchdogRecoveries = 0;
  job.message = 'Replies · Checking your replies through X Search.';
  addEvent(job, job.message);
  await navigate(job);
}

async function openRepostProfile(job, reason) {
  job.repostProfile = true;
  job.repostIssue = String(reason || 'X did not confirm the Reposts timeline.').slice(0, 140);
  job.documentId = null;
  job.recoveries = 0;
  job.redirects = 0;
  job.watchdogRecoveries = 0;
  job.skippedHere = 0;
  job.nextActionAt = Math.max(job.nextActionAt || 0, Date.now() + Cleaner.itemRetryRest);
  job.waitUntil = job.nextActionAt;
  job.message = 'Reposts · The reposts list did not load. Checking your profile for active repost controls.';
  addEvent(job, job.message);
  await navigate(job);
}

async function unavailableSection(job, reason) {
  recordInterruptedAction(job, 'The last action could not be verified before switching the recovery route.');
  if (job.section === 2 && !job.repostProfile) {
    await openRepostProfile(job, reason);
    return;
  }
  if ((job.section === 3 || job.section === 4) && !job.history) {
    await openHistory(job);
    return;
  }
  if (job.section === 1 && !job.replySearch) {
    await openReplySearch(job);
    return;
  }
  const detail = reason + ' Other selected sections will continue. Retry cleanup to check this section again.';
  (job.unavailable ||= {})[job.section] = detail;
  await finishSection(job, { result: 'review', detail });
}

async function recoverRoute(job, url) {
  const path = Cleaner.route(url);
  const name = sections[job.section].name;
  const destination = path === '/home' || path === '' ? 'Home' : path;
  if (job.status === 'stopping') {
    await pause(job, 'Stopped while the X page was changing.', 'manual');
    return;
  }
  if (path === null || /^\/(?:login|logout|account\/(?:access|suspended)|i\/flow\/(?:challenge|verify|login|signup))(?:\/|$)/.test(path)) {
    await pause(job, path === null ? 'The cleanup tab left x.com. Continue cleanup to reopen your profile.'
      : 'X requires sign-in or an account check. Resolve it on X, then continue.', path === null ? 'issue' : 'x');
    return;
  }

  const detail = `X opened ${destination} while loading ${name}.`;
  addEvent(job, detail);
  if (job.pending) {
    recordInterruptedAction(job, detail + ' The last action could not be verified.');
  } else if (!job.problem?.url) {
    job.problem = { text: detail };
  }
  if ((job.redirects || 0) < 2) {
    job.redirects = (job.redirects || 0) + 1;
    job.message = `${detail} Reopening ${name} (${job.redirects}/2)…`;
    await navigate(job);
    return;
  }
  await unavailableSection(job, detail + ' The redirect persisted after two retries.');
}

async function start(old, selection, pace, accountHandle, paceMode) {
  if (old?.status === 'running' || old?.status === 'stopping' ||
      old?.alertPending || (old?.handle === accountHandle && old.ratePaused && old.waitUntil > Date.now())) return old;
  const selected = Cleaner.sectionOrder.filter(index => Array.isArray(selection) && selection.includes(index));
  if (!selected.length) {
    throw new Error('Select at least one category.');
  }
  if (!Cleaner.validPace(pace)) throw new Error('Enter a delay from 0 to 3600 seconds.');
  let tab;
  if (old?.handle === accountHandle && ['paused', 'review', 'finished', 'previewed'].includes(old.status)) {
    try {
      const candidate = await chrome.tabs.get(old.tabId);
      if (Cleaner.route(candidate.url) !== null) {
        tab = await chrome.tabs.update(candidate.id, { active: true, url: 'about:blank' });
      }
    } catch {
      // The previous cleanup tab no longer exists.
    }
  }
  if (!tab) tab = await chrome.tabs.create({ url: 'about:blank', active: true });
  const keep = old?.handle === accountHandle && ['paused', 'review'].includes(old.status) && Cleaner.sameSections(old.selected, selected) &&
    !old.preview;
  const resume = keep && old.status === 'paused' && String(old.selected) === String(selected) && selected.includes(old.section);
  if (keep && old.pending) recordInterruptedAction(old, 'Chrome closed before the last action could be verified.');
  const job = {
    id: crypto.randomUUID(), tabId: tab.id, status: 'running', selected, handle: accountHandle,
    itemFailures: keep && old.status === 'paused' ? old.itemFailures || {} : {},
    unavailable: resume ? old.unavailable || {} : {},
    confirmed: keep && old.status === 'review'
      ? Object.fromEntries(Object.keys(old.confirmed || {}).map(key => [key, 1]))
      : keep ? old.confirmed || {} : {},
    bookmarkBulkTried: keep && Boolean(old.bookmarkBulkTried),
    bookmarksCleared: keep && Boolean(old.bookmarksCleared),
    events: keep ? old.events || [] : [],
    section: resume ? old.section : selected[0], pass: resume ? old.pass : 1,
    documentId: null, pending: null, nextActionAt: old?.handle === accountHandle ? old.nextActionAt || 0 : 0,
    pace, paceMode, successStreak: 0, watchdogRecoveries: 0,
    changes: resume ? old.changes : 0, results: resume ? old.results : [],
    totals: keep ? old.totals : { deleted: 0, reposts: 0, bookmarks: 0, likes: 0, skipped: 0, errors: 0 },
    message: '', problem: keep ? old.problem : null, repostIssue: resume ? old.repostIssue : null
  };
  if (old?.handle === accountHandle && old.tabId === tab.id) {
    job.originalAutoDiscardable = old.originalAutoDiscardable;
  }
  await openSection(job, { repostProfile: Boolean(resume && old.repostProfile) });
  return job;
}

async function finishSection(job, message) {
  job.results.push({
    section: job.section,
    name: sections[job.section].name,
    status: message.result === 'clear' && !job.repostIssue ? 'clear' : 'review',
    detail: String(job.repostIssue
      ? `${job.repostIssue} Profile fallback: ${message.detail || 'scan ended.'}`
      : message.detail || '').slice(0, 250)
  });
  addEvent(job, `${sections[job.section].name} · ${job.results.at(-1).status === 'clear' ? 'Scanned' : 'Needs review'}`);
  const next = job.selected[job.selected.indexOf(job.section) + 1];
  if (next !== undefined) {
    job.section = next;
    await openSection(job);
    return;
  }
  if (job.pass < MAX_PASSES) {
    job.pass++;
    job.section = job.selected[0];
    job.changes = 0;
    job.results = [];
    await openSection(job);
    return;
  }
  const unresolved = job.changes > 0 || job.results.some(result => result.status !== 'clear');
  job.status = unresolved ? 'review' : 'finished';
  job.alertPending = unresolved;
  job.waitUntil = 0;
  if (!unresolved) job.problem = null;
  job.documentId = null;
  job.message = unresolved
    ? 'Cleanup stopped with items or sections to review. Check the details and retry when X is ready.'
    : 'No more eligible items surfaced in the selected sections.';
  await write(job);
}

async function recoverSection(job, reason) {
  if (job.recoveries >= 2) {
    await unavailableSection(job, reason);
    return;
  }
  job.recoveries++;
  if (job.paceMode === 'auto') job.pace = Cleaner.automaticPace(job, false);
  job.nextActionAt = Math.max(job.nextActionAt, Date.now() + 30000 * job.recoveries);
  job.problem = { text: reason, url: job.problem?.url };
  job.waitUntil = job.nextActionAt;
  job.message = `Retrying ${sections[job.section].name} after an X page issue.`;
  addEvent(job, `${sections[job.section].name} · Retry ${job.recoveries}/2 · ${reason}`);
  await navigate(job, { refresh: true });
}

function validPending(item, accountHandle) {
  if (item?.kind === 'bookmark-bulk') return item.url === Cleaner.sectionUrl(3);
  return item && /^(delete|repost|bookmark|like)$/.test(item.kind) &&
    /^https:\/\/x\.com\/[a-z0-9_]{1,15}\/status\/\d{1,22}$/i.test(item.url) &&
    (item.kind !== 'delete' || new URL(item.url).pathname.split('/')[1].toLowerCase() === accountHandle);
}

async function detectAccount() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (Cleaner.route(tab?.url) === null) return { reason: 'Open a signed-in x.com tab to start.' };
  try {
    const response = await chrome.tabs.sendMessage(tab.id, { type: 'detectAccount' }, { frameId: 0 });
    const handle = Cleaner.normalizeHandle(response?.handle);
    return handle ? { handle } : { reason: 'Sign in to X and wait for the page to load.' };
  } catch {
    return { reason: 'Reload this X tab so X Cleaner can detect your account.' };
  }
}

async function handle(message, sender) {
  const job = await read();
  const fromPopup = sender.url === chrome.runtime.getURL('popup.html');
  if (fromPopup && message.type === 'status') {
    const saved = await report(job, !job);
    if (!saved?.handle) return null;
    if (!job && ['running', 'stopping'].includes(saved?.status)) {
      return pause(saved, 'Cleanup was interrupted. When X is ready, choose Continue cleanup.');
    }
    return job || await report(null);
  }
  if (fromPopup && message.type === 'detect') return detectAccount();
  if (fromPopup && message.type === 'openX') {
    await chrome.tabs.create({ url: Cleaner.origin, active: true });
    return null;
  }
  if (message.type === 'acknowledge') {
    const saved = await report(job, true);
    const fromCleanupTab = saved && sender.tab?.id === saved.tabId && sender.frameId === 0;
    if (!saved?.alertPending || saved.id !== message.id || !(fromPopup || fromCleanupTab)) return null;
    saved.alertPending = false;
    await write(saved);
    return saved;
  }
  if (fromPopup && message.type === 'start') {
    if (job?.handle && ['running', 'stopping'].includes(job.status)) return job;
    const detected = await detectAccount();
    if (!detected.handle) throw new Error(detected.reason);
    if (detected.handle !== message.expectedHandle) {
      throw new Error('The active account changed. Reopen X Cleaner and check the account shown.');
    }
    const old = await report(job, true);
    const previous = !job && ['running', 'stopping'].includes(old?.status)
      ? await pause(old, 'Cleanup was interrupted. When X is ready, choose Continue cleanup.') : old;
    const pace = message.pace === undefined ? (previous?.handle === detected.handle
      ? previous.pace ?? Cleaner.defaultPace : Cleaner.defaultPace) : message.pace;
    const paceMode = message.paceMode === 'auto' ? 'auto'
      : message.paceMode === 'manual' || message.pace !== undefined ? 'manual'
        : previous?.handle === detected.handle ? previous.paceMode || 'auto' : 'auto';
    if (message.preview === true) throw new Error('Reopen the updated X Cleaner popup to start cleanup.');
    return start(previous, message.selection, paceMode === 'auto' ? 10000 : pace, detected.handle, paceMode);
  }
  if (!job?.handle) return null;
  const fromTab = sender.tab?.id === job.tabId && sender.frameId === 0;
  if (fromTab && message.type === 'hello' && job.alertPending) return job;
  if (!['running', 'stopping'].includes(job.status)) return null;

  if (message.type === 'stop' && (fromPopup || (fromTab && sender.documentId === job.documentId))) {
    if (!job.pending) return pause(job, 'Stopped. Continue cleanup to rescan.', 'manual');
    job.status = 'stopping';
    job.message = 'Stopping after the current request…';
    await write(job);
    return job;
  }
  if (!fromTab) return null;
  if (message.type === 'hello' && job.status === 'running' && atSection(job, sender.url)) {
    if (job.documentId && job.documentId !== sender.documentId) {
      recordInterruptedAction(job, 'X reloaded the page before the last action could be verified. Rescanning this section.');
      job.message = `Rechecking ${sections[job.section].name} after a page reload…`;
    }
    job.documentId = sender.documentId;
    job.lastContact = Date.now();
    await write(job);
    return job;
  }
  if (message.id !== job.id || message.section !== job.section || message.pass !== job.pass ||
      sender.documentId !== job.documentId) return null;

  if (message.type === 'routeLost') {
    const tab = await chrome.tabs.get(job.tabId);
    if (!tab.pendingUrl && !atSection(job, tab.url)) await recoverRoute(job, tab.url);
    return job;
  }
  if (!atSection(job, sender.url)) return null;
  job.lastContact = Date.now();

  if (message.type === 'settled' && job.pending?.url === message.url) {
    const duration = Date.now() - (job.actionStartedAt || Date.now());
    if (message.ok) {
      const kind = job.pending.kind;
      const key = itemKey(job.pending);
      const confirmed = job.confirmed ||= {};
      if (kind === 'bookmark-bulk') {
        job.bookmarksCleared = true;
        addEvent(job, 'Bookmarks · X confirmed an empty list after clearing all.');
      } else {
        const counter = { delete: 'deleted', repost: 'reposts', bookmark: 'bookmarks', like: 'likes' }[kind];
        if (!confirmed[key]) job.totals[counter]++;
        confirmed[key] = (confirmed[key] || 0) + 1;
        if (kind === 'delete') job.message = `Delete confirmed · ${job.totals.deleted} deleted this run.`;
      }
      job.changes++;
      job.watchdogRecoveries = 0;
      if (job.itemFailures) delete job.itemFailures[key];
      if (job.problem?.url === message.url) job.problem = null;
    } else if (!message.cancelled) {
      job.totals.errors++;
      const attempts = rememberFailure(job, job.pending);
      const detail = String(message.issue || 'X did not verify the action.').slice(0, 220);
      const retry = job.pending.kind === 'bookmark-bulk' ? ''
        : attempts < MAX_ITEM_ATTEMPTS ? ' Will recheck this item.' : ' Retry limit reached for this run.';
      job.problem = { text: detail + retry, url: message.url };
      addEvent(job, `${sections[job.section].name} · ${detail}${retry}`);
    }
    if (message.sent || message.ok) {
      job.batchActions++;
    }
    if (job.paceMode === 'auto' && !message.cancelled) {
      job.pace = Cleaner.automaticPace(job, message.ok === true, duration);
    }
    if (job.pending.kind === 'bookmark-bulk' && message.ok) job.batchActions = 1;
    job.nextActionAt = Math.max(job.nextActionAt || 0, Date.now() + (job.pace ?? Cleaner.defaultPace));
    if (!job.refreshPending && job.batchActions >= Cleaner.batchSize) {
      job.refreshPending = true;
      addEvent(job, `${sections[job.section].name} · Break after six actions`);
      job.nextActionAt = Math.max(job.nextActionAt, Date.now() + Cleaner.batchRest);
    }
    job.pending = null;
    if (message.restriction?.reason) {
      return pause(job, String(message.restriction.reason).slice(0, 350),
        message.restriction.rateLimited === true ? 'rate-limit' : 'x');
    }
    if (job.status === 'stopping') {
      return pause(job, message.ok || message.cancelled ? 'Stopped.' : `Stopped. Check the last attempted item: ${message.url}`, 'manual');
    }
    await write(job);
    return job;
  }
  if (message.type === 'pause') {
    const kind = message.rateLimited === true ? 'rate-limit' : message.x === true ? 'x' : 'issue';
    return pause(job, String(message.reason).slice(0, 350), kind);
  }
  if (job.status !== 'running') return null;

  if (message.type === 'progress') {
    if (Number.isSafeInteger(message.skipped) && message.skipped >= job.skippedHere) {
      job.totals.skipped += message.skipped - job.skippedHere;
      job.skippedHere = message.skipped;
    }
    job.message = String(message.text).slice(0, 150);
    job.waitUntil = message.waiting ? job.nextActionAt : 0;
    await write(job);
    return job;
  }
  if (message.type === 'begin' && !job.preview && !job.pending && validPending(message.item, job.handle)) {
    const target = message.item.kind;
    const permitted = (target === 'delete' && job.section <= 1 && job.selected.includes(job.section)) ||
      (target === 'repost' && job.section === 2) ||
      (target === 'bookmark' && job.section === 3) ||
      (target === 'bookmark-bulk' && job.section === 3 && !job.bookmarkBulkTried &&
        Cleaner.route(sender.url) === Cleaner.route(Cleaner.sectionUrl(3))) || (target === 'like' && job.section === 4);
    if (!permitted) return null;
    const remaining = job.nextActionAt - Date.now();
    if (remaining > 0) return { wait: remaining };
    const key = itemKey(message.item);
    if (job.confirmed?.[key] >= MAX_ITEM_ATTEMPTS) {
      job.problem = { text: 'X showed this item again after two confirmations. Open it to check its current state.', url: message.item.url };
      await write(job);
      return { skipped: true, issue: job.problem.text };
    }
    const failure = job.itemFailures?.[key];
    const attempts = typeof failure === 'number' ? failure : failure?.attempts || 0;
    if (attempts >= MAX_ITEM_ATTEMPTS) return { skipped: true };
    if (failure?.retryAt > Date.now()) return { retry: true };
    if (job.refreshPending) {
      job.refreshPending = false;
      job.batchActions = 0;
    }
    if (target === 'bookmark-bulk') job.bookmarkBulkTried = true;
    job.pending = message.item;
    job.actionStartedAt = Date.now();
    job.waitUntil = 0;
    await write(job);
    return { allowed: true };
  }
  if (message.type === 'check' && job.pending?.url === message.url) {
    const tab = await chrome.tabs.get(job.tabId);
    return { allowed: atSection(job, tab.url) && !tab.pendingUrl };
  }
  if (message.type === 'sectionIssue') {
    if (job.pending) recordInterruptedAction(job, 'The last action could not be verified.');
    const reason = String(message.reason || 'X could not load this section.').slice(0, 180);
    await recoverSection(job, reason);
    return job;
  }
  if (message.type === 'sectionEnd' && !job.pending) {
    if (job.section === 2 && !job.repostProfile && message.result !== 'clear') {
      await openRepostProfile(job, message.detail);
      return job;
    }
    if (job.section === 1 && !job.replySearch && message.checkReplySearch === true) {
      await openReplySearch(job);
      return job;
    }
    if ((job.section === 3 || job.section === 4) && !job.history && message.fallback) {
      await openHistory(job);
      return job;
    }
    await finishSection(job, message);
    return job;
  }
  return null;
}

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  serial(() => handle(message, sender)).then(
    result => respond({ result }),
    error => respond({ error: error.message })
  );
  return true;
});

chrome.tabs.onRemoved.addListener(tabId => {
  serial(async () => {
    const job = await read();
    if (job?.tabId === tabId && ['running', 'stopping'].includes(job.status)) {
      await pause(job, 'The cleanup tab closed. Continue cleanup to rescan.');
    }
  }).catch(console.error);
});

chrome.tabs.onUpdated.addListener((tabId, change, eventTab) => {
  if (change.status !== 'complete' && !change.url) return;
  serial(async () => {
    const job = await read();
    if (!job?.handle || job.tabId !== tabId || !['running', 'stopping'].includes(job.status) ||
        eventTab.url === 'about:blank' || atSection(job, eventTab.url)) return;
    const tab = await chrome.tabs.get(tabId);
    if (tab.pendingUrl || tab.status === 'loading' || tab.url !== eventTab.url) return;
    await recoverRoute(job, tab.url);
  }).catch(console.error);
});

if (chrome.alarms) {
  chrome.alarms.onAlarm.addListener(alarm => {
    if (alarm.name === WATCHDOG) serial(checkHealth).catch(console.error);
  });
  serial(async () => {
    const job = await read();
    if (job && ['running', 'stopping'].includes(job.status)) {
      if (!await chrome.alarms.get(WATCHDOG)) await chrome.alarms.create(WATCHDOG, { periodInMinutes: 0.5 });
    } else {
      await chrome.alarms.clear(WATCHDOG);
    }
  }).catch(console.error);
}

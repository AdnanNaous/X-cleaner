'use strict';

(() => {
  const ARTICLE = 'article[data-testid="tweet"]';
  const AUTHOR = '[data-testid="User-Name"], [data-testid="UserName"]';
  const PROFILE_LINK = [
    'a[data-testid="AppTabBar_Profile_Link"]',
    'header nav a[aria-label="Profile"]',
    'header nav a[aria-label="الملف الشخصي"]'
  ].join(', ');
  const ACCOUNT_BUTTON = '[data-testid="SideNav_AccountSwitcher_Button"]';
  const DROPDOWN = '[data-testid="Dropdown"], [role="menu"]';
  const CONFIRM = '[data-testid="confirmationSheetConfirm"]';
  const CANCEL = '[data-testid="confirmationSheetCancel"]';
  const SHEET = '[data-testid="confirmationSheetDialog"], [role="dialog"], [role="alertdialog"], [aria-modal="true"]';
  const NOTICES = '[data-testid="toast"], [role="status"], [role="alert"]';
  const sections = Cleaner.sections;
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const emptyLabels = [
    'no posts yet', 'hasn’t posted', "hasn't posted", 'when you post', 'no replies yet',
    'no reposts yet', 'hasn’t reposted', "hasn't reposted", 'when you repost',
    'save posts for later', 'no bookmarks yet', 'haven’t added any posts to your bookmarks',
    "haven't added any posts to your bookmarks", 'no likes yet', 'you haven’t liked',
    "you haven't liked", 'when you like a post', 'ليس هناك منشورات', 'لا توجد منشورات',
    'لم ينشر', 'لا توجد ردود', 'لا توجد إعادات نشر', 'احفظ المنشورات لوقت لاحق',
    'لا توجد علامات مرجعية', 'لا توجد إعجابات'
  ];
  const deleteLabels = new Set(['delete', 'delete post', 'حذف', 'حذف المنشور']);
  const deletedNotices = new Set([
    'post deleted', 'your post was deleted', 'your post has been deleted',
    'tweet deleted', 'your tweet was deleted', 'your tweet has been deleted',
    'تم حذف المنشور', 'تم حذف منشورك'
  ]);
  const undoLabels = new Set(['undo repost', 'undo retweet', 'التراجع عن إعادة النشر', 'إلغاء إعادة النشر']);
  const undoNotices = new Set(['repost undone', 'retweet undone', 'your repost was undone',
    'تم التراجع عن إعادة النشر', 'تم إلغاء إعادة النشر']);
  const toggleLabels = {
    repost: ['undo repost', 'undo retweet', 'reposted', 'التراجع عن إعادة النشر', 'إلغاء إعادة النشر', 'أعدت النشر'],
    bookmark: ['remove bookmark', 'remove from bookmarks', 'bookmarked', 'إزالة العلامة المرجعية', 'إزالة من العلامات المرجعية'],
    like: ['unlike', 'liked', 'إلغاء الإعجاب', 'إزالة الإعجاب']
  };
  const addLabels = {
    repost: ['repost', 'retweet', 'إعادة النشر'],
    bookmark: ['bookmark', 'add bookmark', 'add to bookmarks', 'إضافة علامة مرجعية', 'إضافة إلى العلامات المرجعية'],
    like: ['like', 'إعجاب']
  };
  const bookmarkNotices = new Set(['removed from your bookmarks', 'post removed from your bookmarks',
    'تمت الإزالة من علاماتك المرجعية', 'تمت إزالة المنشور من العلامات المرجعية']);
  const repostLabels = new Set(['you reposted', 'you retweeted', 'لقد أعدت النشر', 'أعدت النشر', 'قمت بإعادة النشر']);
  const historyLabels = {
    3: new Set(['bookmarks', 'العلامات المرجعية']),
    4: new Set(['likes', 'الإعجابات', 'تسجيلات الإعجاب'])
  };
  let job;
  let cancelled = false;
  let panel;
  let paint;
  let panelHost;
  let observer;
  let batchDue = false;
  let nextActionAt = 0;
  let lastIssue = '';
  let blockedByX;

  const normalize = value => String(value || '').replace(/[\u200e\u200f\u061c]/g, '').trim().replace(/\s+/g, ' ').toLowerCase();
  const visible = node => node?.isConnected && node.getClientRects().length > 0 &&
    !node.closest('[hidden]');
  const all = (root, selector) => [...(root?.querySelectorAll(selector) || [])].filter(visible);
  const unique = (root, selector) => {
    const matches = all(root, selector);
    return matches.length === 1 ? matches[0] : null;
  };
  const primary = () => unique(document, '[data-testid="primaryColumn"]') || unique(document, 'main');
  const cardMarkup = (card, node) => node?.closest(ARTICLE) === card &&
    !node.closest('[data-testid="quoteTweet"], [data-testid="card.wrapper"]');
  const owned = (card, selector) => {
    const matches = all(card, selector).filter(node => cardMarkup(card, node));
    return matches.length === 1 ? matches[0] : null;
  };

  async function ask(type, fields = {}) {
    const response = await chrome.runtime.sendMessage({
      type, id: job?.id, section: job?.section, pass: job?.pass, ...fields
    });
    if (response?.error) throw new Error(response.error);
    return response?.result;
  }

  async function waitFor(read, timeout = 9000, allowStopping = false) {
    const end = Date.now() + timeout;
    while ((allowStopping || !cancelled) && Date.now() < end) {
      const result = read();
      if (result) return result;
      await sleep(180);
    }
    return null;
  }

  function profileHandle(url) {
    return Cleaner.route(url)?.match(/^\/([a-z0-9_]{1,15})$/)?.[1];
  }

  function signedInHandle() {
    const visibleLinks = all(document, PROFILE_LINK);
    const links = visibleLinks.length ? visibleLinks : [...document.querySelectorAll(PROFILE_LINK)];
    const nav = [...new Set(links.map(link => profileHandle(link.href)).filter(Boolean))];
    const accountButton = unique(document, ACCOUNT_BUTTON);
    const handles = (accountButton?.innerText || '').split('\n')
      .map(line => line.trim().match(/^@([a-z0-9_]{1,15})$/i)?.[1])
      .filter(Boolean).map(handle => handle.toLowerCase());
    const detected = [...new Set([...nav, ...handles])];
    return detected.length === 1 ? detected[0] : null;
  }

  function account() {
    const detected = signedInHandle();
    if (detected) return detected === job?.handle ? 'verified' : 'mismatch';
    return null;
  }

  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id === chrome.runtime.id && message.type === 'detectAccount') {
      respond({ handle: signedInHandle() });
    }
  });

  function currentHistory() {
    return Cleaner.route(location.href)?.startsWith('/i/history');
  }

  function selectedTab(tab) {
    return tab?.getAttribute('aria-selected') === 'true' ||
      ['page', 'true'].includes(tab?.getAttribute('aria-current'));
  }

  function getHistoryTab() {
    const matches = all(primary(), '[role="tab"], [role="tablist"] a').filter(tab =>
      labelled(tab, historyLabels[job.section]));
    return matches.length === 1 ? matches[0] : null;
  }

  function correctView() {
    if (!atSection()) return false;
    if (job.section === 2) {
      const tab = getRepostTab();
      if (tab) return selectedTab(tab);
    }
    if (!currentHistory()) return true;
    const tab = getHistoryTab();
    if (tab) return selectedTab(tab);
    const route = Cleaner.route(location.href);
    if (job.section === 4) return route === '/i/history/likes';
    return job.section === 3 && route === '/i/history/bookmarks';
  }

  function atSection() {
    return Cleaner.atSection(job.section, location.href, job.handle, job.history, job.replySearch, job.repostProfile);
  }

  function getRepostTab() {
    const expected = Cleaner.route(Cleaner.sectionUrl(job.repostProfile ? 0 : 2, job.handle));
    const labels = new Set(job.repostProfile ? ['posts', 'المنشورات'] : ['reposts', 'إعادات النشر']);
    const tabs = all(primary(), '[role="tab"], [role="tablist"] a').filter(tab => !tab.closest(ARTICLE));
    const linked = tabs.filter(tab => Cleaner.route(tab.href) === expected);
    const matches = linked.length ? linked : tabs.filter(tab => labelled(tab, labels));
    return matches.length === 1 ? matches[0] : null;
  }

  async function prepareView() {
    if (job.section === 2 && atSection()) {
      const tab = getRepostTab();
      if (tab && !selectedTab(tab) && account() === 'verified' && !cancelled) {
        tab.click();
        return Boolean(await waitFor(() => correctView() || !atSection(), 8000)) && correctView();
      }
    }
    if (!currentHistory()) return correctView();
    if (correctView()) return true;
    const knownHistoryTab = await waitFor(getHistoryTab, 5000);
    if (knownHistoryTab && account() === 'verified' && !cancelled) {
      knownHistoryTab.click();
      return Boolean(await waitFor(correctView, 8000));
    }
    return false;
  }

  function parseCard(card) {
    const permalink = /^\/([a-z0-9_]{1,15})\/status\/(\d{1,22})$/;
    const header = owned(card, AUTHOR);
    const authors = [...new Set(all(header, 'a[href]').map(link => profileHandle(link.href)).filter(Boolean))];
    const route = link => {
      const path = Cleaner.route(link?.href);
      const web = path?.match(/^\/i\/(?:web\/)?status\/(\d{1,22})$/);
      return web && authors.length === 1 ? '/' + authors[0] + '/status/' + web[1] : path;
    };
    const matchRoutes = links => [...new Set(links.map(route)
      .filter(path => permalink.test(path)))];
    const timestamps = matchRoutes(all(card, 'time').filter(node => cardMarkup(card, node))
      .map(node => node.closest('a[href]')));
    const routes = timestamps.length ? timestamps : matchRoutes(all(header, 'a[href*="/status/"]')
      .filter(node => !node.closest('[data-testid="quoteTweet"], [data-testid="card.wrapper"]')));
    const match = routes.length === 1 ? routes[0].match(permalink) : null;
    if (!match) return null;
    const [, author, id] = match;
    return { card, author, id, url: Cleaner.origin + match[0] };
  }

  function socialContext(card) {
    return normalize(owned(card, '[data-testid="socialContext"]')?.innerText);
  }

  function repostedHere(card) {
    if (repostLabels.has(socialContext(card))) return true;
    return job.section === 2 && atSection();
  }

  function markedReply(card) {
    return all(card, '[data-testid="replyingTo"], [data-testid="replyingToContext"], [dir="auto"]')
      .some(node => {
        if (node.closest(ARTICLE) !== card ||
            node.closest('[data-testid="tweetText"], [data-testid="User-Name"], [data-testid="UserName"], [data-testid="quoteTweet"], [data-testid="card.wrapper"]')) return false;
        if (['replyingTo', 'replyingToContext'].includes(node.getAttribute('data-testid'))) return true;
        const context = normalize(node.innerText).match(/^(?:replying to|رد(?:ً?ا|ّ)? على) (.+)$/)?.[1];
        return Boolean(context && (/^@[a-z0-9_]{1,15}\b/.test(context) ||
          all(node, 'a[href]').some(link => profileHandle(link.href))));
      });
  }

  function identify(card, data = parseCard(card)) {
    if (!data) return null;
    if (job.section === 3) {
      return toggle(card, 'bookmark') || (!toggle(card, 'bookmark', false) && shareControl(card)) ? 'bookmark' : null;
    }
    if (job.section === 4) return toggle(card, 'like') ? 'like' : null;
    if (job.section === 2) {
      return repostedHere(card) && toggle(card, 'repost') ? 'repost' : null;
    }
    if (data.author !== job.handle || repostLabels.has(socialContext(card))) return null;
    if (job.section === 1 && (job.replySearch ? atSection() : markedReply(card))) return 'delete';
    if (job.section === 0 && !markedReply(card)) return 'delete';
    return null;
  }

  function shareControl(card) {
    const exact = owned(card, '[data-testid="share"]');
    if (exact) return exact;
    const matches = all(card, 'button[aria-label], [role="button"][aria-label]')
      .filter(node => cardMarkup(card, node) &&
        ['share', 'share post', 'مشاركة', 'مشاركة المنشور'].includes(normalize(node.getAttribute('aria-label'))));
    return matches.length === 1 ? matches[0] : null;
  }

  function toggle(card, kind, active = true) {
    const tests = active ? { repost: 'unretweet', bookmark: 'removeBookmark', like: 'unlike' }
      : { repost: 'retweet', bookmark: 'bookmark', like: 'like' };
    const exact = owned(card, `[data-testid="${tests[kind]}"]`);
    if (exact) return exact;
    const labels = active ? toggleLabels[kind] : addLabels[kind];
    const matches = all(card, 'button[aria-label], [role="button"][aria-label]')
      .filter(node => cardMarkup(card, node))
      .filter(node => {
        const text = normalize(node.getAttribute('aria-label')).replace(/^\d[\d,.\s]*\s*/, '');
        const pressed = node.getAttribute('aria-pressed');
        if (active && pressed === 'false') return false;
        if (!active && pressed === 'true') return false;
        if (labels.some(label => text === label || text.endsWith('. ' + label) || text.endsWith(', ' + label))) return true;
        return active && pressed === 'true' && addLabels[kind].includes(text);
      });
    return matches.length === 1 ? matches[0] : null;
  }

  function enabled(node) {
    return visible(node) && !node.disabled && node.getAttribute('aria-disabled') !== 'true';
  }

  function menuItem(selector, names) {
    const roots = all(document, DROPDOWN);
    const matches = new Set(roots.flatMap(root => all(root, selector)).filter(enabled));
    if (names) {
      for (const item of matches) {
        if (!labelled(item, names)) matches.delete(item);
      }
    }
    return matches.size === 1 ? [...matches][0] : null;
  }

  function labelled(node, labels) {
    return [node?.innerText, node?.textContent, node?.getAttribute('aria-label')]
      .some(value => labels.has(normalize(value).replace(/[.!。]$/, '')));
  }

  function confirmationSheet(previous) {
    const candidates = all(document, CONFIRM).filter(button =>
      !previous.has(button) && !button.closest('[aria-hidden="true"], [inert]'));
    if (candidates.length !== 1) return null;
    const button = candidates[0];
    const sheet = button.closest(SHEET);
    return sheet ? { button, sheet } : null;
  }

  function closeConfirmation(confirmation) {
    const cancel = unique(confirmation?.sheet, CANCEL);
    if (enabled(cancel)) cancel.click();
  }

  function newNotice(previous, labels) {
    return all(document, NOTICES).some(node => {
      const message = normalize(node.innerText || node.textContent);
      return previous.get(node) !== message && labels.has(message.replace(/[.!。]$/, ''));
    });
  }

  function pageNotice() {
    return all(document, '[data-testid="toast"], [data-testid="emptyState"], [role="alert"], [role="alertdialog"]')
      .filter(node => !node.closest(ARTICLE)).map(node => normalize(node.innerText)).join(' ');
  }

  function restriction() {
    if (blockedByX) return blockedByX;
    const notice = pageNotice();
    if (/verify (you are|your identity)|automated request|account (is |has been )?(locked|suspended|restricted)|تم (قفل|تعليق|تقييد) حسابك/.test(notice)) {
      blockedByX = { reason: 'X displayed an account check or restriction. Resolve the prompt on X before continuing.', x: true };
    } else if (/rate limit|too many requests|temporarily limited|daily limit|request limit|معدل الطلبات|طلبات كثيرة|الحد اليومي/.test(notice)) {
      blockedByX = { reason: 'X displayed a rate limit. Cleanup paused. Continue once the wait ends and X works normally.', rateLimited: true };
    }
    return blockedByX;
  }

  function rateLimited() {
    return Boolean(restriction());
  }

  async function waitUntil(time) {
    while (!cancelled && Date.now() < time) {
      if (!routeAndAccount()) return false;
      await sleep(Math.min(700, time - Date.now()));
    }
    return !cancelled && routeAndAccount();
  }

  function timelineError() {
    const notice = pageNotice();
    return /something went wrong|failed to load|please retry|حدث خطأ ما|تعذر التحميل/.test(notice) ||
      all(primary(), '[data-testid="retry"]').length > 0;
  }

  function emptyTimeline() {
    return all(primary(), '[data-testid="emptyState"], [data-testid="empty_state_header_text"]')
      .some(node => {
        const label = normalize(node.innerText);
        return emptyLabels.some(text => label.includes(text)) ||
          (job.replySearch && /^(?:no results for|no results found|لا توجد نتائج|لم يتم العثور على نتائج)/.test(label));
      });
  }

  function remainingPostCount() {
    const column = primary();
    const back = unique(column, '[data-testid="app-bar-back"]');
    let header = back?.parentElement;
    for (let depth = 0; header && header !== column && depth < 5; depth++, header = header.parentElement) {
      const text = header.innerText || '';
      if (text.length > 180 || header.querySelector(ARTICLE)) break;
      const count = text.split('\n').map(normalize)
        .find(line => /^\d[\d.,]*[kmb]? posts?$/.test(line));
      if (count) return /^0 posts?$/.test(count) ? null : count;
    }
    return null;
  }

  function showPanel() {
    const host = document.createElement('div');
    const root = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = `
      :host {position:fixed; inset:auto auto 14px 14px; z-index:2147483647; color-scheme:dark}
      aside {box-sizing:border-box; width:min(290px,calc(100vw - 28px)); background:#000; color:#fff; border:1px solid #777; border-radius:7px; padding:10px 12px; box-shadow:0 6px 18px #0008; font:11px/1.4 system-ui,sans-serif}
      header {display:flex; justify-content:space-between; align-items:center; gap:10px}
      strong {font-size:13px} p {margin:5px 0; overflow-wrap:anywhere} small {color:#c1c1c1}
      button {font:600 12px system-ui,sans-serif; background:#fff; color:#000; padding:7px 12px; border:0; border-radius:5px; cursor:pointer}
      button:disabled {opacity:.55; cursor:default}
      button:focus-visible {outline:2px solid #fff; outline-offset:3px}
      aside[data-done] {border-color:#fff}
      aside[data-alert] {border:2px solid #fff}
      small[hidden] {display:none}
      #elapsed {display:block; margin:0 0 7px; font-variant-numeric:tabular-nums}
      #elapsed[hidden] {display:none}
    `;
    const box = document.createElement('aside');
    box.setAttribute('aria-label', 'X Cleaner');
    const header = document.createElement('header');
    const title = document.createElement('strong');
    const control = document.createElement('button');
    control.type = 'button';
    const description = document.createElement('p');
    description.setAttribute('role', 'status');
    const route = document.createElement('small');
    const counts = document.createElement('small');
    const elapsed = document.createElement('small');
    elapsed.id = 'elapsed';
    const updateElapsed = () => {
      elapsed.hidden = !(panel?.status === 'paused' && panel.pausedAt && ['x', 'rate-limit'].includes(panel.pauseKind));
      if (!elapsed.hidden) elapsed.textContent = 'Paused for ' + Cleaner.elapsedSince(panel.pausedAt);
    };
    let timer;
    header.append(title, control);
    box.append(header, route, description, elapsed, counts);
    root.append(style, box);
    document.body.append(host);
    panelHost = host;
    control.addEventListener('click', () => {
      if (panel?.alertPending) {
        control.disabled = true;
        ask('acknowledge').then(state => { if (!state) control.disabled = false; }).catch(() => { control.disabled = false; });
      } else if (panel?.status === 'running') {
        control.disabled = true;
        ask('stop').catch(() => { control.disabled = false; });
      } else {
        clearInterval(timer);
        host.remove();
      }
    });
    return state => {
      panel = state;
      title.textContent = state.status === 'finished' ? '✓ Cleanup complete'
        : state.alertPending ? 'Cleanup stopped' : 'X Cleaner';
      box.toggleAttribute('data-done', state.status === 'finished');
      box.toggleAttribute('data-alert', Boolean(state.alertPending));
      control.textContent = state.alertPending ? 'OK' : state.status === 'running' ? 'Stop' : 'Dismiss';
      control.disabled = state.status === 'stopping';
      route.textContent = ['running', 'stopping', 'paused'].includes(state.status)
        ? `${Cleaner.sections[state.section].name} · ${state.selected.indexOf(state.section) + 1}/${state.selected.length}` : '';
      route.hidden = !route.textContent;
      description.textContent = state.alertPending
        ? state.message.split(' Check the last attempted item: ')[0] + ' Select OK to acknowledge. The run stays stopped.'
        : state.message;
      updateElapsed();
      if (!elapsed.hidden && !timer) timer = setInterval(updateElapsed, 1000);
      if (elapsed.hidden && timer) {
        clearInterval(timer);
        timer = undefined;
      }
      const { deleted, reposts, bookmarks, likes, skipped, errors } = state.totals;
      const bookmarkCount = state.bookmarksCleared ? 'All' : bookmarks;
      counts.textContent = `${deleted} deleted · ${reposts} reposts · ${bookmarkCount} bookmarks · ${likes} likes` +
        (errors ? ` · ${errors} errors` : '');
    };
  }

  function routeAndAccount() {
    return correctView() && account() === 'verified' && !rateLimited();
  }

  function validCard(item) {
    if (!visible(item.card)) return false;
    const latest = parseCard(item.card);
    return latest?.id === item.id && latest.author === item.author &&
      identify(item.card, latest) === item.kind;
  }

  async function apply(item) {
    lastIssue = '';
    item.card.scrollIntoView({ block: 'center', behavior: 'smooth' });
    await sleep(120);
    const rebind = () => {
      if (validCard(item)) return true;
      const candidates = all(primary(), ARTICLE).map(parseCard).filter(data =>
        data?.id === item.id && data.author === item.author);
      if (candidates.length !== 1 || identify(candidates[0].card, candidates[0]) !== item.kind) return false;
      item.card = candidates[0].card;
      return true;
    };
    if (cancelled || !routeAndAccount() || !rebind()) return 'deferred';

    let permission = await ask('begin', { item: { kind: item.kind, url: item.url } });
    while (permission?.wait) {
      if (!await waitUntil(Date.now() + permission.wait) || !rebind()) return 'deferred';
      permission = await ask('begin', { item: { kind: item.kind, url: item.url } });
    }
    if (permission?.retry) return 'retry';
    if (permission?.skipped) {
      lastIssue = permission.issue || 'Retry limit reached for this item.';
      return 'skipped';
    }
    if (!permission?.allowed) return 'deferred';
    let clicked = false;
    let directRepost = false;
    let repostBaseline;
    const cardsInView = () => all(primary(), ARTICLE);
    const matchesTarget = data => data?.id === item.id && data.author === item.author;
    const matchingCards = () => cardsInView().map(parseCard).filter(matchesTarget);
    const timelineReadable = () => cardsInView().some(card => parseCard(card)) || emptyTimeline();
    const repostDisappeared = () => !job.repostProfile && !visible(item.card) &&
      !matchingCards().length && timelineReadable();
    let deleteBaseline;
    let confirmation;
    let openedMenu = false;
    let ok = false;
    const fail = issue => {
      lastIssue = issue;
      return 'failed';
    };
    try {
      let button;
      if (item.kind === 'delete') {
        if (all(document, DROPDOWN).length || all(document, SHEET).length || all(document, CONFIRM).length) {
          return fail('An X menu or dialog was already open.');
        }
        const menu = owned(item.card, '[data-testid="caret"]') ||
          owned(item.card, 'button[aria-label="More"], [role="button"][aria-label="More"], button[aria-label="المزيد"]');
        if (!enabled(menu)) return fail('The post menu was missing or disabled.');
        menu.click();
        openedMenu = true;
        const remove = await waitFor(() => menuItem('[role="menuitem"], [data-testid="delete"]', deleteLabels), 7500);
        if (!enabled(remove)) return fail('The post menu did not offer a recognizable Delete command.');
        await sleep(150);
        if (cancelled || !enabled(remove) || !routeAndAccount() || !rebind()) {
          return fail('The post changed while its menu was open.');
        }
        deleteBaseline = new Set(all(document, CONFIRM));
        if (panelHost) panelHost.style.visibility = 'hidden';
        remove.click();
        confirmation = await waitFor(() => confirmationSheet(deleteBaseline), 7500);
        if (!confirmation) return fail('X did not open a recognizable Delete confirmation.');
      } else if (item.kind === 'repost') {
        if (all(document, DROPDOWN).length || all(document, '[role="dialog"], [aria-modal="true"]').length) {
          return fail('An X menu or dialog was already open.');
        }
        const repostButton = toggle(item.card, 'repost');
        if (!enabled(repostButton)) return fail('The repost control was missing or disabled.');
        const approval = await ask('check', { url: item.url });
        if (cancelled || !approval?.allowed || !routeAndAccount() || !validCard(item) ||
            toggle(item.card, 'repost') !== repostButton || !enabled(repostButton)) {
          return fail('The repost changed before its control could be used.');
        }
        repostBaseline = new Map(all(document, NOTICES).map(node =>
          [node, normalize(node.innerText || node.textContent)]));
        repostButton.click();
        clicked = true;
        openedMenu = true;
        const action = await waitFor(() => {
          const choice = unique(document, '[data-testid="unretweetConfirm"]');
          const confirm = enabled(choice) && labelled(choice, undoLabels) ? choice
            : menuItem('[role="menuitem"]', undoLabels) ||
              menuItem('button, [role="button"]', undoLabels);
          if (confirm) return { button: confirm };
          if (restriction() || timelineError()) return { issue: true };
          const live = matchingCards();
          if (newNotice(repostBaseline, undoNotices) || repostDisappeared() ||
              (live.length === 1 && toggle(live[0].card, 'repost', false) && !toggle(live[0].card, 'repost'))) {
            return { direct: true };
          }
          return null;
        }, 7500);
        if (action?.issue) return fail('X reported an error while opening Undo repost.');
        if (!action) return fail('The Undo repost confirmation did not appear.');
        directRepost = Boolean(action.direct);
        button = action.button;
      } else {
        button = toggle(item.card, item.kind);
        if (!button && item.kind === 'bookmark') {
          if (all(document, DROPDOWN).length || all(document, SHEET).length) return fail('An X menu or dialog was already open.');
          const share = shareControl(item.card);
          if (!enabled(share)) return fail('The bookmark control was missing.');
          share.click();
          openedMenu = true;
          button = await waitFor(() => menuItem('[role="menuitem"], [data-testid="removeBookmark"]',
            new Set(toggleLabels.bookmark)), 3500);
          if (!button) return fail('X did not offer a Remove bookmark action in this post’s menu.');
        }
      }
      await sleep(150);
      const approval = await ask('check', { url: item.url });
      if (cancelled || !approval?.allowed) return fail('The cleanup tab changed or stopped before confirmation.');
      if (!routeAndAccount()) return fail('X changed the active section or account before confirmation.');
      if (item.kind === 'delete') {
        // X can remount the timeline while its dialog is open. The validated menu action owns this dialog.
        confirmation = confirmationSheet(deleteBaseline);
        if (!confirmation || !enabled(confirmation.button) || !labelled(confirmation.button, deleteLabels)) {
          return fail('The Delete confirmation was missing, disabled or unrecognized.');
        }
        button = confirmation.button;
      } else if (!directRepost) {
        if (!rebind()) return fail('The item changed before confirmation.');
        if (item.kind !== 'repost' && !openedMenu) button = toggle(item.card, item.kind);
        if (!enabled(button)) return fail('The action control changed before confirmation.');
      }
      const oldNotices = new Map(all(document, NOTICES).map(node =>
        [node, normalize(node.innerText || node.textContent)]));
      const targetStillRendered = () => matchingCards().length > 0;
      const presentBeforeClick = item.kind !== 'delete' || targetStillRendered();
      if (!directRepost) {
        button.click();
        clicked = true;
      }
      if (item.kind === 'delete') {
        ask('progress', { text: 'Delete sent · Waiting for X to confirm…' }).catch(console.warn);
      }

      const changed = () => {
        const timeline = primary();
        if (!timeline) return false;
        const cards = all(timeline, ARTICLE);
        const live = cards.map(parseCard).filter(data => data?.id === item.id && data.author === item.author);
        if (item.kind !== 'delete' && live.length) {
          return live.every(data => Boolean(toggle(data.card, item.kind, false)) && !toggle(data.card, item.kind));
        }
        if (live.length) return false;
        if (item.kind === 'repost') return repostDisappeared() && !all(document, DROPDOWN).length;
        if (item.card.isConnected && parseCard(item.card)?.id === item.id) return false;
        if (!cards.length && !emptyTimeline()) return false;
        if (item.kind === 'delete') return presentBeforeClick && !targetStillRendered();
        return !cards.some(card => parseCard(card)?.id === item.id && identify(card) === item.kind);
      };
      let changedAt = null;
      const verified = await waitFor(() => {
        if (restriction() || timelineError()) return 'issue';
        if (item.kind === 'bookmark' && newNotice(oldNotices, bookmarkNotices)) return 'verified';
        if (item.kind === 'repost' && newNotice(repostBaseline, undoNotices)) return 'verified';
        if (deleteBaseline) {
          const open = confirmationSheet(deleteBaseline);
          if (newNotice(oldNotices, deletedNotices)) {
            closeConfirmation(open);
            return 'verified';
          }
          if (open) {
            changedAt = null;
            return null;
          }
          if (panelHost) panelHost.style.visibility = '';
        }
        if (!changed()) {
          changedAt = null;
          return null;
        }
        changedAt ??= Date.now();
        const stableFor = item.kind === 'delete' || (item.kind === 'repost' && !targetStillRendered()) ? 1250 : 650;
        return Date.now() - changedAt >= stableFor ? 'verified' : null;
      }, 22000, true);
      ok = verified === 'verified' && routeAndAccount();
      return ok ? 'changed' : fail(verified === 'issue'
        ? 'X showed an error after the action was sent.'
        : 'X did not confirm the change within 22 seconds.');
    } finally {
      if (deleteBaseline) {
        if (!ok) closeConfirmation(confirmationSheet(deleteBaseline));
        if (panelHost) panelHost.style.visibility = '';
      }
      if (!ok && !cancelled && openedMenu && all(document, DROPDOWN).length) {
        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      }
      const state = await ask('settled', {
        url: item.url, ok, sent: clicked, issue: lastIssue, cancelled: cancelled && !clicked,
        restriction: restriction()
      });
      batchDue = Boolean(state?.refreshPending);
      nextActionAt = state?.nextActionAt || 0;
      if (state) Object.assign(job, { pace: state.pace, paceMode: state.paceMode });
    }
  }

  async function clearBookmarks() {
    if (job.preview || job.section !== 3 || job.bookmarkBulkTried ||
        Cleaner.route(location.href) !== '/i/bookmarks' || !all(primary(), ARTICLE).length) return;
    if (!await waitUntil(nextActionAt) || all(document, DROPDOWN).length ||
        all(document, '[role="dialog"], [aria-modal="true"]').length) return;
    const main = primary();
    const headerMenus = all(main, 'button[aria-label="More"], button[aria-label="المزيد"]')
      .filter(node => !node.closest(ARTICLE) && !node.closest('[data-testid="cellInnerDiv"]'));
    const button = unique(main, '[data-testid="bookmarkOverflowButton"]') ||
      (headerMenus.length === 1 ? headerMenus[0] : null);
    if (!enabled(button)) return;
    const bulk = { kind: 'bookmark-bulk', url: Cleaner.sectionUrl(3) };
    const clearLabels = new Set(['clear all bookmarks', 'مسح جميع العلامات المرجعية']);
    const confirmLabels = new Set(['clear', 'clear all', ...clearLabels, 'مسح']);
    let allowed = false;
    let sent = false;
    let ok = false;
    let dialog;
    try {
      if (!routeAndAccount()) return;
      button.click();
      const clear = await waitFor(() =>
        menuItem('[role="menuitem"], [data-testid="clearAllBookmarks"], [data-testid="clearBookmarks"]', clearLabels), 2500);
      if (cancelled || !enabled(clear) || !routeAndAccount()) return;
      const permission = await ask('begin', { item: bulk });
      if (!permission?.allowed) return;
      allowed = true;
      await ask('progress', { text: 'Bookmarks · Clearing all with X’s built-in command' });
      if (cancelled || !routeAndAccount() || !enabled(clear)) return;
      clear.click();
      const confirm = await waitFor(() => {
        const candidate = unique(document, '[data-testid="confirmationSheetConfirm"]');
        const sheet = candidate?.closest('[role="dialog"], [aria-modal="true"]');
        if (!enabled(candidate) || !sheet || !confirmLabels.has(normalize(candidate.innerText)) ||
            ![...clearLabels].some(label => normalize(sheet.innerText).includes(label))) return null;
        dialog = sheet;
        return candidate;
      }, 7500);
      if (!confirm) return;
      const approval = await ask('check', { url: bulk.url });
      if (cancelled || !approval?.allowed || !routeAndAccount() || !enabled(confirm) || !dialog?.contains(confirm)) return;
      confirm.click();
      sent = true;
      const bookmarksEmpty = () => emptyTimeline() && !all(primary(), ARTICLE).length;
      await waitFor(() => bookmarksEmpty() || restriction() || timelineError(), 22000, true);
      ok = Boolean(bookmarksEmpty() && routeAndAccount() && !timelineError());
    } finally {
      if (!sent && dialog?.isConnected) {
        const cancel = unique(dialog, '[data-testid="confirmationSheetCancel"]');
        if (enabled(cancel)) cancel.click();
      } else if (!sent && all(document, DROPDOWN).length) {
        button.click();
      }
      if (allowed) {
        const state = await ask('settled', {
          url: bulk.url, ok, sent, cancelled: cancelled && !sent,
          issue: 'The bulk bookmark clear could not be verified. Checking bookmarks individually.',
          restriction: restriction()
        });
        batchDue = Boolean(state?.refreshPending);
        nextActionAt = state?.nextActionAt || 0;
        if (state) Object.assign(job, { pace: state.pace, paceMode: state.paceMode });
      }
    }
  }

  async function reportLostView() {
    const blocked = restriction();
    if (blocked) return ask('pause', blocked);
    if (account() === 'mismatch') {
      return ask('pause', { reason: `The active X account changed. Switch back to @${job.handle} and continue.` });
    }
    if (!atSection()) return ask('routeLost');
    return ask('sectionIssue', { reason: 'The page stopped showing the expected section or account controls.' });
  }

  async function scan() {
    const name = sections[job.section].name;
    await waitFor(() => account() || restriction() ||
      !atSection(), 18000);
    if (cancelled) return;
    if (account() !== 'verified' || restriction() || !atSection()) {
      await reportLostView();
      return;
    }
    if (!await prepareView()) {
      if (!cancelled) await reportLostView();
      return;
    }
    const blocked = restriction();
    if (blocked) {
      await ask('pause', blocked);
      return;
    }
    if (job.waitUntil > Date.now() && !await waitUntil(job.waitUntil)) {
      if (!cancelled) await reportLostView();
      return;
    }
    const ready = await waitFor(() => {
      const column = primary();
      return all(column, ARTICLE).length || emptyTimeline() || timelineError() || rateLimited();
    }, 18000);
    if (!ready && !cancelled) {
      const reason = 'X did not load a readable timeline.';
      if (job.section === 1 && !job.replySearch) {
        await ask('sectionEnd', { result: 'review', detail: reason, checkReplySearch: true });
      } else if ([3, 4].includes(job.section) && !job.history) {
        await ask('sectionEnd', { result: 'review', detail: reason, fallback: true });
      } else {
        await ask('sectionIssue', { reason });
      }
      return;
    }

    await clearBookmarks();
    if (cancelled) return;
    const skipped = new Set();
    const failures = new Set();
    const ambiguous = new Set();
    const needsRetry = new Set();
    const removed = new Set();
    const scrollRoot = document.scrollingElement;
    let still = 0;
    let errorsInARow = 0;
    let everSawCards = false;
    let everSawTarget = false;
    let checkReplySearch = false;
    let previous = '';
    let lastReport = '';
    let lastSkipped = -1;
    let lastContact = 0;
    let rechecked = false;
    let detail = '';
    let repeatDeferred = 0;
    let deferredKey;

    async function update(text, waiting = false) {
      if (text === lastReport && skipped.size === lastSkipped && Date.now() - lastContact < 30000) return;
      lastContact = Date.now();
      lastReport = text;
      lastSkipped = skipped.size;
      await ask('progress', { text, skipped: skipped.size, waiting });
    }

    window.scrollTo({ top: 0, behavior: 'instant' });
    while (!cancelled) {
      const blocked = restriction();
      if (blocked) {
        await ask('pause', blocked);
        return;
      }
      if (!routeAndAccount()) {
        await reportLostView();
        return;
      }
      if (timelineError()) {
        detail = 'X reported a timeline loading error.';
        break;
      }
      if (batchDue) {
        await update(`${name} · Break after six actions`, true);
        if (await waitUntil(nextActionAt)) batchDue = false;
        continue;
      }
      const cards = all(primary(), ARTICLE);
      everSawCards ||= cards.length > 0;
      let next;
      const marker = [];
      for (const card of cards) {
        const data = parseCard(card);
        const kind = identify(card, data);
        const key = data?.id || normalize(card.innerText).slice(0, 160) || 'unknown-card';
        marker.push(key);
        if (kind) {
          everSawTarget = true;
          ambiguous.delete(key);
          if (!removed.has(key) && !failures.has(key)) next ||= { ...data, kind };
          continue;
        }
        // Context cards in Replies can belong to someone else. They are never targets.
        const ownHeader = !data && all(owned(card, AUTHOR), 'a[href]')
          .some(link => profileHandle(link.href) === job.handle);
        const seemsEligible = !data && (job.section >= 2 || ownHeader ||
          (job.section === 1 && markedReply(card)));
        const missingToggle = data && job.section >= 2 && !removed.has(key) && !(job.section === 2 && job.repostProfile);
        if (job.section === 1 && !job.replySearch &&
            (seemsEligible || (data?.author === job.handle && !repostLabels.has(socialContext(card))))) {
          checkReplySearch = true;
          continue;
        }
        if (seemsEligible || missingToggle) ambiguous.add(key);
        else skipped.add(key);
      }

      if (next) {
        if (nextActionAt > Date.now()) {
          await update(`${name} · Waiting before the next action`, true);
          if (!await waitUntil(nextActionAt)) continue;
          continue;
        }
        const verbs = { delete: 'Deleting', repost: 'Undoing repost', bookmark: 'Removing bookmark', like: 'Removing like' };
        await update(`${name} · ${verbs[next.kind]} · Pass ${job.pass}`);
        const result = await apply(next);
        if (cancelled) return;
        if (result === 'retry') {
          failures.add(next.id);
          needsRetry.add(next.id);
          continue;
        }
        if (result === 'skipped') {
          failures.add(next.id);
          continue;
        }
        if (result === 'deferred') {
          if (next.id !== deferredKey) {
            deferredKey = next.id;
            repeatDeferred = 0;
          }
          if (++repeatDeferred < 4) await sleep(400);
          else {
            failures.add(next.id);
            needsRetry.add(next.id);
            lastIssue = 'An item repeatedly changed before its control could be used.';
          }
          continue;
        }
        deferredKey = null;
        repeatDeferred = 0;
        if (result === 'changed') {
          removed.add(next.id);
          errorsInARow = 0;
          still = 0;
        } else {
          failures.add(next.id);
          needsRetry.add(next.id);
          if (++errorsInARow === 3 && !restriction()) {
            await ask('sectionIssue', { reason: lastIssue });
            return;
          }
        }
        continue;
      }

      await update(`${name} · Scanning for older items · Pass ${job.pass}`);
      const empty = emptyTimeline() && !cards.length;
      const y = scrollRoot.scrollTop;
      const max = Math.max(0, scrollRoot.scrollHeight - scrollRoot.clientHeight);
      const atBottom = y >= max - 12;
      const signature = `${marker.join(',')}/${max}`;
      const loading = all(primary(), '[role="progressbar"], [data-testid="spinner"]').length > 0;
      still = atBottom && signature === previous && !loading ? still + 1 : 0;
      previous = signature;
      if (empty || still >= 5) {
        if (rechecked || (!needsRetry.size && !ambiguous.size)) break;
        rechecked = true;
        if (needsRetry.size) {
          await update(`${name} · Waiting to recheck deferred items`);
          if (!await waitUntil(Math.max(nextActionAt, Date.now() + Cleaner.itemRetryRest))) {
            if (!cancelled) await reportLostView();
            return;
          }
          for (const key of needsRetry) failures.delete(key);
          needsRetry.clear();
        }
        ambiguous.clear();
        still = 0;
        previous = '';
        window.scrollTo({ top: 0, behavior: 'instant' });
        await sleep(950);
        continue;
      }
      if (loading) {
        const loaded = await waitFor(() =>
          !all(primary(), '[role="progressbar"], [data-testid="spinner"]').length ||
          rateLimited() || timelineError(), 30000);
        if (!loaded && !cancelled) {
          detail = 'X kept loading older items.';
          break;
        }
      }
      window.scrollBy({ top: Math.max(250, window.innerHeight * 0.65), behavior: 'smooth' });
      await sleep(atBottom ? 1800 : 950);
    }
    if (cancelled) return;
    if (detail) {
      await ask('sectionIssue', { reason: detail });
      return;
    }
    if (!detail && failures.size) detail = `${failures.size} item(s) could not be verified. ${lastIssue}`.trim();
    if (!detail && ambiguous.size) detail = `${ambiguous.size} card(s) lacked a recognizable action or permalink.`;
    if (!detail && !everSawCards && !emptyTimeline()) detail = 'X did not confirm that the section is empty.';
    if (!detail && job.section === 0 && job.pass > 1 && job.selected.length === sections.length && !removed.size) {
      const remaining = remainingPostCount();
      if (remaining) detail = `X still reports ${remaining} on the profile.`;
    }
    if (!detail && job.replySearch && everSawCards && !everSawTarget && !emptyTimeline()) {
      detail = 'X Search did not show any verifiable replies from your account.';
    }
    await ask('sectionEnd', {
      result: detail ? 'review' : 'clear',
      detail: detail || 'No more eligible items surfaced.',
      fallback: !everSawCards && !emptyTimeline(),
      checkReplySearch: job.section === 1 && !job.replySearch &&
        (checkReplySearch || (!everSawTarget && !emptyTimeline()))
    });
  }

  async function run() {
    job = await ask('hello');
    if (!job || (job.status !== 'running' && !job.alertPending)) return;
    batchDue = Boolean(job.refreshPending);
    nextActionAt = job.nextActionAt || 0;
    document.addEventListener('pointerdown', event => {
      if (job.status !== 'running' || !event.isTrusted || cancelled || !event.target.closest?.('main, header')) return;
      cancelled = true;
      ask('stop').catch(() => {});
    }, true);
    paint = showPanel();
    paint(job);
    observer = (changes, area) => {
      if (area !== 'local') return;
      const state = changes.report?.newValue;
      if (!state) return;
      cancelled ||= state?.id !== job.id || state.status !== 'running' ||
        state.section !== job.section || state.pass !== job.pass;
      if (state?.id !== job.id) return;
      paint(state);
    };
    chrome.storage.onChanged.addListener(observer);
    const latest = (await chrome.storage.local.get('report')).report;
    if (latest) observer({ report: { newValue: latest } }, 'local');
    if (!cancelled && job.status === 'running' && !job.preview) await scan();
  }

  run().catch(async error => {
    if (job && !cancelled) {
      try {
        if (!routeAndAccount()) await reportLostView();
        else await ask('sectionIssue', { reason: `X Cleaner hit a page issue. ${error.message}` });
      } catch {
        if (paint) paint({ ...job, status: 'paused', message: 'Cleanup interrupted. Reopen X Cleaner.' });
      }
    }
  });
})();
